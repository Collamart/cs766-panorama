
There are 18 jpeg images in this test image set, each 384 x 512 pixels.
The focal length of the camera for all images was 595 pixels.  

If you use images from this set, be sure that images overlap sufficiently to enable sufficient corresponding points to be found.  

